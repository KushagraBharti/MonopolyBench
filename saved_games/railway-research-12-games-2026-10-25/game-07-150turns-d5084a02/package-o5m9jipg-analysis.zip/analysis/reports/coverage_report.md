# Coverage Report: package-o5m9jipg

## Canonical Run Artifact Presence

- Expected top-level run artifacts: `44`
- Present: `44`
- Missing: `0`

No canonical run top-level artifacts are missing.

## Layout Contract

- `run/`: canonical raw run artifacts.
- `quality_check/`: request/response quality-check text files.
- `analysis/`: current standardized cross-run analysis.
- `saved_games/archive/package-o5m9jipg/`: preserved legacy analysis and previous generated zips.
