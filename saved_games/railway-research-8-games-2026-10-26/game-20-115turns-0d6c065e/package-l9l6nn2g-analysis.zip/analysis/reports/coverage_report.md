# Coverage Report: package-l9l6nn2g

## Canonical Run Artifact Presence

- Expected top-level run artifacts: `44`
- Present: `44`
- Missing: `0`

No canonical run top-level artifacts are missing.

## Layout Contract

- `run/`: canonical raw run artifacts.
- `quality_check/`: request/response quality-check text files.
- `analysis/`: current standardized cross-run analysis.
- `saved_games/archive/package-l9l6nn2g/`: preserved legacy analysis and previous generated zips.
