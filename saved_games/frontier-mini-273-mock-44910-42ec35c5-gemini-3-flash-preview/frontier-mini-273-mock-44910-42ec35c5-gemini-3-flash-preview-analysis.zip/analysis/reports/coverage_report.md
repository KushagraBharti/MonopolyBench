# Coverage Report: frontier-mini-273-mock-44910-42ec35c5-gemini-3-flash-preview

## Canonical Run Artifact Presence

- Expected top-level run artifacts: `44`
- Present: `42`
- Missing: `2`

## Missing

- `state_replay_report.json`
- `artifact_replay_report.json`

## Layout Contract

- `run/`: canonical raw run artifacts.
- `quality_check/`: request/response quality-check text files.
- `analysis/`: current standardized cross-run analysis.
- `saved_games/archive/frontier-mini-273-mock-44910-42ec35c5-gemini-3-flash-preview/`: preserved legacy analysis and previous generated zips.
